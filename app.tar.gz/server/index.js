'use strict';

/**
 * BPMN-Компилятор — сервер.
 * API:
 *   GET  /api/health
 *   POST /api/generate { text, llm? }             -> { graph, xml, report }
 *   POST /api/edit     { graph, instruction, llm? } -> { graph, xml, report }
 *   POST /api/compile  { graph }                  -> { graph, xml, report }
 *   POST /api/clarify  { graph, issueId, answer, decision } -> { graph, xml, report }
 */

const path = require('path');
const fs = require('fs');
const envFile = path.join(__dirname, '..', '.env');
if (fs.existsSync(envFile)) process.loadEnvFile(envFile);
require('./llm/proxy').configureProxy();
const express = require('express');
const { runPipeline, recompile, clarify } = require('./pipeline/pipeline');
const provider = require('./llm/provider');
const {createLimiter}=require('./limits');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '256kb' }));
app.use(createLimiter());
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options','nosniff');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control','no-store');
  next();
});
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/examples', express.static(path.join(__dirname, '..', 'examples')));

app.get('/api/health', (req, res) => {
  const cfg = provider.resolveConfig(null);
  res.json({
    ok: true,
    llmConfigured: cfg.ok,
    model: cfg.ok ? cfg.model : null,
    baseUrl: cfg.ok ? cfg.baseUrl : null,
    fallback: 'встроенный эвристический парсер',
    version: require('../package.json').version,
    clientLlmConfigAllowed: process.env.ALLOW_CLIENT_LLM_CONFIG === 'true'
  });
});

const wrap = fn => (req, res) => {
  fn(req, res).catch(e => {
    const status = e.status || 500;
    res.status(status).json({ error: e.message || String(e), checks:e.checks });
  });
};

app.post('/api/generate', wrap(async (req, res) => {
  const text = String((req.body && req.body.text) || '').trim();
  if (text.length < 3) return res.status(400).json({ error: 'Пустое описание процесса' });
  if (text.length > 20000) return res.status(413).json({error:'Описание слишком длинное: максимум 20 000 символов'});
  const result = await runPipeline({ text, llm: req.body.llm, mode: 'generate' });
  res.json(result);
}));

app.post('/api/edit', wrap(async (req, res) => {
  const { graph, instruction, llm } = req.body || {};
  if (!graph || !graph.nodes) return res.status(400).json({ error: 'Нет текущего графа' });
  const inst = String(instruction || '').trim();
  if (!inst) return res.status(400).json({ error: 'Пустая инструкция правки' });
  if (inst.length > 2000) return res.status(413).json({error:'Инструкция слишком длинная'});
  const result = await runPipeline({ graph, instruction: inst, llm, mode: 'edit' });
  res.json(result);
}));

app.post('/api/compile', wrap(async (req, res) => {
  const { graph } = req.body || {};
  if (!graph || !graph.nodes) return res.status(400).json({ error: 'Нет графа' });
  res.json(await recompile(graph));
}));
app.post('/api/clarify',wrap(async(req,res)=>{
  const {graph,issueId,answer,decision,llm}=req.body||{};
  if(!graph||!issueId) return res.status(400).json({error:'Нет графа или вопроса'});
  res.json(await clarify({graph,issueId,answer,decision,llm}));
}));

app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') return res.status(413).json({error:'Тело запроса слишком большое'});
  if (err instanceof SyntaxError) return res.status(400).json({error:'Некорректный JSON'});
  res.status(err.status || 500).json({error:err.message || 'Ошибка сервера'});
});
const PORT = process.env.PORT || 3000;
if (require.main === module) app.listen(PORT, process.env.HOST || '127.0.0.1', () => {
  const cfg = provider.resolveConfig(null);
  console.log('BPMN-Компилятор запущен: http://localhost:' + PORT);
  console.log('LLM: ' + (cfg.ok ? cfg.model + ' @ ' + cfg.baseUrl : 'не настроен — работает встроенный эвристический парсер'));
});
module.exports = app;
