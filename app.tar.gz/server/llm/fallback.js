'use strict';

/**
 * Эвристический парсер русского текста процесса -> IR-граф.
 * Детерминированный «двигатель безопасности»: демо и CI работают без LLM-ключа.
 * Понимает: последовательность, условия (если/то/иначе), параллельность, завершение.
 */

const ROLES = 'сотрудник|специалист|дежурный|руководитель|менеджер|бухгалтер|юрист|система|администратор|заявитель|клиент|оператор|инженер|аналитик|рекрутер|наставник|инициатор|финансовый директор|офис-менеджер|служба|диспетчер|мастер|начальник';
const ACTOR_START = new RegExp('^((?:' + ROLES + ')(?:\\s+(?:ИБ|ИТ|отдела|закупок|ИТ-направления|поддержки|безопасности))?)(?=\\s)', 'i');
function actorOf(clause) {
  const s = clause.replace(/^(?:затем|потом|далее|в первый день)\s+/i, '');
  const first = s.match(ACTOR_START);
  if (first) return first[1].charAt(0).toUpperCase() + first[1].slice(1);
  const last = s.match(new RegExp('(?:согласовывает|утверждает|подписывает)\\s+((?:' + ROLES + ')(?:\\s+отдела)?)', 'i'));
  return last ? last[1].charAt(0).toUpperCase() + last[1].slice(1) : '';
}

function splitSentences(text) {
  return String(text)
    .replace(/\s+/g, ' ')
    .split(/(?<=[.!?;])\s+/)
    .map(s => s.trim())
    .filter(Boolean);
}

function splitClauses(sentence) {
  return sentence
    .split(/,\s*(?=затем|потом|далее|после этого|параллельно|одновременно)\s*/i)
    .map(c => c.trim())
    .filter(Boolean)
    .flatMap(c => c.split(/\s+(?=затем|потом|далее|после этого)\s+/i).map(x => x.trim()))
    .filter(Boolean);
}

const END_RE = /(процесс\s+)?(завершает|завершается|завершение|считается заверш|конец процесса|^конец)/i;

function cleanLabel(clause) {
  let s = clause
    .replace(/^(и\s+|а\s+|затем\s+|потом\s+|далее\s+|после этого\s+)/i, '')
    .replace(/^(необходимо|нужно|требуется|следует|происходит|выполняется|начинается)\s+/i, '')
    .replace(ACTOR_START, '')
    .replace(/[.!?;]+$/, '')
    .trim();
  if (!s) s = clause.replace(/[.!?;]+$/, '').trim();
  if (s.length > 70) s = s.slice(0, 69) + '…';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

class GraphBuilder {
  constructor(name) {
    this.nodes = [];
    this.edges = [];
    this.i = 0;
    this.name = name || 'Бизнес-процесс';
    this.issues=[]; this.participants=[]; this.messages=[]; this.pending=null;
  }
  id() { return 'n' + (++this.i); }
  node(type, label, lane, source) {
    const n = { id: this.id(), type, label: label || '', lane: lane || 'Участник процесса',...(source?{source}:{}) };
    const documents=source?[...source.matchAll(/(?:документ(?:а|ы)?\s*)?[«"]([^»"]+)[»"]/g)].map(m=>m[1]):[];
    if(type==='task'&&documents.length) {
      if(/формиру|созда|готов|отправля|переда|выда/i.test(source)) n.outputs=documents;
      if(/получа|использу|проверя|на основании/i.test(source)) n.inputs=documents;
    }
    this.nodes.push(n);
    if(type==='task'&&source) this.external(n,source);
    return n;
  }
  issue(data) { this.issues.push({id:'question'+(this.issues.length+1),...data}); }
  external(node,source) {
    const external=source.match(/(?:внешн(?:ему|его|им|ий|яя|ей|ую)\s+)(подрядчик(?:у|а|ом)?|поставщик(?:у|а|ом)?|организаци[яиюей]+|компани[яиюей]+)/i);
    if(!external) return;
    const name=/подрядчик/i.test(external[1])?'Подрядчик':/поставщик/i.test(external[1])?'Поставщик':'Внешняя организация';
    let participant=this.participants.find(p=>p.name===name);
    if(!participant) {participant={id:'external'+(this.participants.length+1),name};this.participants.push(participant);}
    if(/отправля|переда/i.test(source)) this.messages.push({from:node.id,to:participant.id,label:(node.outputs||[]).join(', ')||'Сообщение',source});
    else if(/получа/i.test(source)&&/\sот\s/i.test(source)) this.messages.push({from:participant.id,to:node.id,label:(node.inputs||[]).join(', ')||'Ответ',source});
    else this.issue({kind:'external',nodeIds:[node.id],message:'Направление взаимодействия с внешним участником не определено',question:'Что отправляется внешнему участнику или получается от него?',source});
  }
  link(a, b, label) {
    if (!a || !b || a.id === b.id) return;
    if(this.pending&&a.id===this.pending.from) {
      this.issue({...this.pending,to:b.id,nodeIds:[a.id,b.id]}); this.pending=null;return;
    }
    this.edges.push({ from: a.id, to: b.id, label: label || '' });
  }
  chain(prev, clauses) {
    let cur = prev;
    for (const clause of clauses) {
      const r = this.clause(cur, clause);
      cur = r;
    }
    return cur;
  }
  clause(prev, clause) {
    if(/(?:переход|связь|продолжение|дальнейш[а-яё ]+)(?:.{0,35})(?:не описан|неизвест|не указан|не определ|непонят)|логический разрыв/i.test(clause)) {
      this.pending={kind:'flow-gap',from:prev.id,message:'Не описан переход между действиями',question:'Как продолжается процесс после «'+prev.label+'»?',source:clause};return prev;
    }
    // Условие: "если X, то A" [, иначе B]
    const cond = clause.match(/^если\s+(.+?),?\s+то\s+(.+)$/i);
    if (cond) {
      const condText = cleanLabel(cond[1]) + '?';
      const rest = cond[2];
      let thenPart = rest, elsePart = null;
      const elseM = rest.match(/^(.*?)[,;]?\s+(?:иначе|в противном случае)\s+(?:[—–-]\s*)?(.*)$/i);
      if (elseM) { thenPart = elseM[1]; elsePart = elseM[2]; }

      const gw = this.node('exclusiveGateway', condText, prev.lane, cond[1]);
      this.link(prev, gw);
      const results=[this.branch(gw,thenPart,'да')];
      if(elsePart) results.push(this.branch(gw,elsePart,'нет'));
      const live=results.filter(n=>n&&n.type!=='endEvent');
      if(elsePart&&live.length===1) return live[0];
      if(elsePart&&!live.length) return results.find(n=>n?.type==='endEvent')||gw;
      const merge = this.node('exclusiveGateway', '', prev.lane);
      for(const n of live) this.link(n,merge);
      if(!elsePart) this.issue({kind:'missing-branch',from:gw.id,to:merge.id,nodeIds:[gw.id],message:'Не описана отрицательная ветвь условия «'+condText+'»',question:'Что происходит, если условие «'+condText+'» не выполнено?',source:clause});
      return merge;
    }

    // Параллельность: "параллельно A и B" / "одновременно A, B"
    const par = clause.match(/^(?:параллельно|одновременно|в это время)\s+(.+)$/i);
    if (par) {
      let content = par[1];
      const passive = content.match(/^(уведомляется|уведомляются)\s+(.+)$/i);
      if (passive) content = passive[2].split(/\s+и\s+/i).map(role => role + ' получает уведомление').join(' и ');
      const branches = content.split(/\s+и\s+|,\s*/i).map(x => x.trim()).filter(Boolean);
      if (branches.length < 2) return this.clause(prev, content);
      const split = this.node('parallelGateway', '', prev.lane);
      const join = this.node('parallelGateway', '', prev.lane);
      this.link(prev, split);
      for (const b of branches) {
        let last = split;
        for (const c of this.subClauses(b)) {
          const t = this.node('task', cleanLabel(c), actorOf(c), c);
          this.link(last, t);
          last = t;
        }
        this.link(last, join);
      }
      return join;
    }

    // Завершение
    if (END_RE.test(clause)) {
      const end = this.node('endEvent', 'Конец', prev.lane);
      this.link(prev, end);
      return end;
    }

    // Обычная задача
    const label = cleanLabel(clause);
    if (!label) return prev;
    const t = this.node('task', label, actorOf(clause), clause);
    this.link(prev, t);
    return t;
  }
  branch(gateway,text,label) {
    let last=gateway;
    for(const clause of this.subClauses(text)) {
      const returnTo=clause.match(/(?:вернуться|возврат|возвращается|возвращают|возвращает)(?:.{0,50}?)(?:к\s+(?:задаче|шагу|действию)\s+)[«"]([^»"]+)[»"]/i);
      if(returnTo) {
        const target=this.nodes.find(n=>n.type==='task'&&n.label.toLowerCase()===returnTo[1].toLowerCase());
        if(target) this.link(last,target,last===gateway?label:'');
        else this.issue({kind:'missing-return',from:last.id,nodeIds:[last.id],message:'Не найдена задача возврата «'+returnTo[1]+'»',question:'Укажите название существующей задачи, к которой возвращается процесс.',source:clause});
        return null;
      }
      if(END_RE.test(clause)) {const end=this.node('endEvent','Конец',last.lane,clause);this.link(last,end,last===gateway?label:'');return end;}
      const task=this.node('task',cleanLabel(clause),actorOf(clause),clause);
      this.link(last,task,last===gateway?label:'');last=task;
      if(/возвраща[а-яё]*.{0,35}(?:доработ|исправлен)/i.test(clause)) {
        this.issue({kind:'missing-return',from:last.id,nodeIds:[last.id],message:'Не указан дальнейший маршрут после доработки',question:'К какому действию возвращается процесс после доработки?',source:clause});return null;
      }
    }
    return last;
  }
  subClauses(text) {
    const parts = text.split(/\s+и\s+затем\s+|\s+затем\s+|\s+потом\s+|\s+далее\s+/i).map(x => x.trim()).filter(Boolean);
    return parts.length ? parts : [text];
  }
}

/** Главный вход: текст -> IR-граф (всегда завершается, даже на странном входе). */
function parseProcessText(text) {
  const sentences = splitSentences(text);
  const first = sentences[0] || 'Бизнес-процесс';
  const name = first.length > 90 ? first.slice(0, 89) + '…' : first.replace(/[.!?;]+$/, '');

  // Первый короткий пункт без глагола действия считаем заголовком процесса, а не задачей
  const ACTION_RE = /(оформля|созда|отправля|соглас|проверя|подписыва|провод|фиксир|уведомл|принима|переда|заполня|анализир|устраня|возвращает|формиру|готов|получа|пишет|отвеча|закрыва|эскалир|попада|выдаётся|выдается|рассматр|оплачив|рассыл)/i;
  const words = first.replace(/[.!?;]+$/, '').split(' ');
  const titleNoun=/^(?:Согласование|Уведомление|Подписание|Проверка|Создание|Формирование)(?:\s|[.!?;]|$)/i.test(first);
  const isTitle = sentences.length > 1 && words.length <= 5 && !first.includes(',') && !actorOf(first) && (!ACTION_RE.test(first)||titleNoun) && !/^(если|параллельно|одновременно)/i.test(first);

  const b = new GraphBuilder(name);
  const start = b.node('startEvent', 'Начало', actorOf((isTitle ? sentences[1] : first) || ''));
  let cur = start;
  let ended = false;

  for (const sentence of isTitle ? sentences.slice(1) : sentences) {
    if (ended) break;
    if (/^(процесс|он)\s+(начинается|стартует)/i.test(sentence)) continue;
    cur = b.chain(cur, splitClauses(sentence));
    if (cur.type === 'endEvent') ended = true;
  }
  if (!ended) {
    const end = b.node('endEvent', 'Конец', cur.lane);
    b.link(cur, end);
  }
  const firstTask = b.nodes.find(n => n.type === 'task');
  if (firstTask) start.lane = firstTask.lane;
  if(b.pending) b.issue({...b.pending,nodeIds:[b.pending.from]});
  return { name: b.name, lanes: [...new Set(b.nodes.map(n => n.lane))], nodes: b.nodes, edges: b.edges,issues:b.issues,draft:b.issues.length>0,participants:b.participants,messages:b.messages,sourceText:String(text) };
}

module.exports = { parseProcessText };
