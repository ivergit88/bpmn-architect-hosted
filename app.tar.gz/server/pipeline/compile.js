'use strict';

/**
 * Компилятор: IR-граф -> координаты (ELK, слоевой алгоритм Sugiyama)
 * -> BPMN 2.0 XML с BPMNDI через bpmn-moddle.
 * XML сериализуется Moddle. Проверка XSD выполняется независимым скриптом.
 */

const { BpmnModdle } = require('bpmn-moddle');
const ELKModule = require('elkjs/lib/elk.bundled.js');
const ELK = ELKModule.default || ELKModule;

const SIZES = {
  startEvent: { w: 36, h: 36 },
  endEvent: { w: 36, h: 36 },
  task: { w: 180, h: 90 },
  exclusiveGateway: { w: 50, h: 50 },
  parallelGateway: { w: 50, h: 50 },
  inclusiveGateway: { w: 50, h: 50 }
};

const MARGIN = 40;

function toXML(moddle, element, options) {
  return new Promise((resolve, reject) => {
    const done = (err, res) => (err ? reject(err) : resolve(res));
    let maybe;
    try {
      maybe = moddle.toXML(element, options, done);
    } catch (e) { return reject(e); }
    if (maybe && typeof maybe.then === 'function') maybe.then(r => resolve(r), reject);
  });
}

function fromXML(moddle, xml) {
  return new Promise((resolve, reject) => {
    const done = (err, res) => (err ? reject(err) : resolve(res));
    let maybe;
    try {
      maybe = moddle.fromXML(xml, done);
    } catch (e) { return reject(e); }
    if (maybe && typeof maybe.then === 'function') maybe.then(r => resolve(r), reject);
  });
}

/** Слоевой лейаут через ELK (Sugiyama): уровни слева направо. */
async function layout(graph) {
  const elk = new ELK();
  const children = graph.nodes.map(n => {
    const s = SIZES[n.type] || SIZES.task;
    return { id: n.id, width: s.w, height: s.h };
  });
  const edges = graph.edges.map((e, i) => ({ id: 'e' + i, sources: [e.from], targets: [e.to] }));
  const g = {
    id: 'root',
    layoutOptions: {
      'elk.algorithm': 'layered',
      'elk.direction': 'RIGHT',
      'elk.spacing.nodeNode': '80',
      'elk.layered.spacing.nodeNodeBetweenLayers': '110',
      'elk.padding': `[top=${MARGIN},left=${MARGIN},bottom=${MARGIN},right=${MARGIN}]`
    },
    children,
    edges
  };
  const laid = await elk.layout(g);
  const raw = new Map(laid.children.map(c => [c.id,c]));
  const lanes = [], pos = new Map();
  let top = MARGIN;
  for (const name of graph.lanes) {
    const items = graph.nodes.filter(n=>n.lane===name).sort((a,b)=>raw.get(a.id).x-raw.get(b.id).x || raw.get(a.id).y-raw.get(b.id).y);
    const rowEnds = [], assigned = [];
    for (const n of items) {
      const p = raw.get(n.id), x = p.x + 70;
      let row = rowEnds.findIndex(end => end + 24 < x);
      if (row === -1) row = rowEnds.length;
      rowEnds[row] = x + p.width;
      assigned.push({n,p,x,row});
    }
    const height = Math.max(170, rowEnds.length * 140 + 50);
    lanes.push({name,y:top,height});
    for (const {n,p,x,row} of assigned) pos.set(n.id,{x,y:top + 40 + row*140,width:p.width,height:p.height});
    top += height;
  }
  const waypoints = new Map();
  graph.edges.forEach((e,i) => {
    const a = pos.get(e.from), b = pos.get(e.to);
    if (b.x > a.x + a.width) {
      const start = {x:a.x+a.width,y:a.y+a.height/2}, end = {x:b.x,y:b.y+b.height/2};
      const mid = (start.x+end.x)/2;
      waypoints.set('e'+i,[start,{x:mid,y:start.y},{x:mid,y:end.y},end]);
    } else {
      // Обратные переходы/петли идут над узлами, вне их прямоугольников.
      const start = {x:a.x+a.width/2,y:a.y}, end = {x:b.x+b.width/2,y:b.y};
      const channel = Math.min(a.y,b.y) - 24;
      waypoints.set('e'+i,[start,{x:start.x,y:channel},{x:end.x,y:channel},end]);
    }
  });
  const width = Math.max(...[...pos.values()].map(p=>p.x+p.width)) + MARGIN;
  return { pos, waypoints, lanes, width, height:top-MARGIN };
}

function escapeXmlAttr(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Сборка BPMN 2.0 XML (definitions + process + BPMNDI) из графа и координат. */
async function buildXml(graph, pos, waypoints, dimensions) {
  const moddle = new BpmnModdle();

  const processEl = moddle.create('bpmn:Process', {
    id: 'Process_1',
    name: graph.name,
    isExecutable: false
  });
  const laneEls = graph.lanes.map((name,i) => moddle.create('bpmn:Lane',{id:'Lane_'+(i+1),name,flowNodeRef:[]}));
  processEl.laneSets = [moddle.create('bpmn:LaneSet',{id:'LaneSet_1',lanes:laneEls})];
  const participant = moddle.create('bpmn:Participant',{id:'Participant_1',name:graph.name,processRef:processEl});
  const externals=new Map((graph.participants||[]).map((p,i)=>[p.id,moddle.create('bpmn:Participant',{id:'External_'+(i+1),name:p.name})]));
  const collaboration = moddle.create('bpmn:Collaboration',{id:'Collaboration_1',participants:[participant,...externals.values()]});

  const flowById = new Map();
  const nodeEl = new Map();

  for (const [i,n] of graph.nodes.entries()) {
    const type = {
      startEvent: 'bpmn:StartEvent',
      endEvent: 'bpmn:EndEvent',
      task: 'bpmn:Task',
      exclusiveGateway: 'bpmn:ExclusiveGateway',
      parallelGateway: 'bpmn:ParallelGateway',
      inclusiveGateway: 'bpmn:InclusiveGateway'
    }[n.type] || 'bpmn:Task';
    const el = moddle.create(type, { id: 'Node_' + (i+1), name: n.label || undefined, incoming:[],outgoing:[] });
    if(n.source||n.inputs?.length||n.outputs?.length) el.documentation=[moddle.create('bpmn:Documentation',{text:'BPMN-Architect: '+JSON.stringify({source:n.source||'',inputs:n.inputs||[],outputs:n.outputs||[]})})];
    nodeEl.set(n.id, el);
    laneEls[graph.lanes.indexOf(n.lane)].flowNodeRef.push(el);
  }

  for (const [i,e] of graph.edges.entries()) {
    const f = moddle.create('bpmn:SequenceFlow', {
      id: 'Sequence_' + (i+1),
      name: e.label || undefined,
      sourceRef: nodeEl.get(e.from),
      targetRef: nodeEl.get(e.to)
    });
    flowById.set(e.from + '->' + e.to, f);
    nodeEl.get(e.from).outgoing.push(f);
    nodeEl.get(e.to).incoming.push(f);
  }

  // Направление шлюза вычисляем из топологии: split -> Diverging, join -> Converging
  for (const n of graph.nodes) {
    if (!n.type.includes('Gateway')) continue;
    const outs = graph.edges.filter(e => e.from === n.id).length;
    const ins = graph.edges.filter(e => e.to === n.id).length;
    nodeEl.get(n.id).gatewayDirection = outs > ins ? 'Diverging' : ins > outs ? 'Converging' : outs === 1 ? 'Converging' : 'Mixed';
  }

  processEl.flowElements = [
    ...graph.nodes.map(n => nodeEl.get(n.id)),
    ...graph.edges.map(e => flowById.get(e.from + '->' + e.to))
  ];
  const mapId=id=>nodeEl.get(id)?.id||id;
  const metadata={draft:Boolean(graph.draft),sourceText:graph.sourceText||'',issues:(graph.issues||[]).map(i=>({...i,nodeIds:i.nodeIds.map(mapId),...(i.from?{from:mapId(i.from)}:{}),...(i.to?{to:mapId(i.to)}:{})})),clarifications:(graph.clarifications||[]).map(c=>({...c,...(c.from?{from:mapId(c.from)}:{}),...(c.to?{to:mapId(c.to)}:{})}))};
  processEl.documentation=[moddle.create('bpmn:Documentation',{text:'BPMN-Architect: '+JSON.stringify(metadata)})];
  const messages=(graph.messages||[]).map((m,i)=>moddle.create('bpmn:MessageFlow',{id:'Message_'+(i+1),name:m.label||undefined,sourceRef:nodeEl.get(m.from)||externals.get(m.from),targetRef:nodeEl.get(m.to)||externals.get(m.to),...(m.source?{documentation:[moddle.create('bpmn:Documentation',{text:'BPMN-Architect: '+JSON.stringify({source:m.source})})]}:{})}));
  collaboration.messageFlows=messages;
  const artifacts=[];

  // --- BPMNDI ---
  const plane = moddle.create('bpmndi:BPMNPlane', { id: 'BPMNPlane_1', bpmnElement: collaboration });
  const planeElements = [];
  planeElements.push(moddle.create('bpmndi:BPMNShape',{
    id:'ParticipantShape_1',bpmnElement:participant,isHorizontal:true,
    bounds:moddle.create('dc:Bounds',{x:10,y:MARGIN,width:dimensions.width-10,height:dimensions.height})
  }));
  dimensions.lanes.forEach((lane,i)=>planeElements.push(moddle.create('bpmndi:BPMNShape',{
    id:'LaneShape_'+(i+1),bpmnElement:laneEls[i],isHorizontal:true,
    bounds:moddle.create('dc:Bounds',{x:40,y:lane.y,width:dimensions.width-40,height:lane.height})
  })));
  const externalPositions=new Map();
  [...externals.entries()].forEach(([id,external],i)=>{
    const bounds={x:10,y:MARGIN+dimensions.height+80+i*130,width:Math.max(500,dimensions.width-10),height:80};
    externalPositions.set(id,bounds);
    planeElements.push(moddle.create('bpmndi:BPMNShape',{id:'Shape_'+external.id,bpmnElement:external,isHorizontal:true,isExpanded:false,bounds:moddle.create('dc:Bounds',bounds)}));
  });
  (graph.messages||[]).forEach((m,i)=>{
    const internalId=externals.has(m.from)?m.to:m.from,externalId=externals.has(m.from)?m.from:m.to;
    const a=pos.get(internalId),b=externalPositions.get(externalId),x=a.x+a.width/2;
    const start={x,y:a.y+a.height},end={x:Math.min(b.x+b.width-30,Math.max(b.x+50,x)),y:b.y};
    const points=externals.has(m.from)?[end,start]:[start,end];
    planeElements.push(moddle.create('bpmndi:BPMNEdge',{id:'Shape_Message_'+(i+1),bpmnElement:messages[i],waypoint:points.map(p=>moddle.create('dc:Point',p))}));
  });
  (graph.issues||[]).forEach((issue,i)=>{
    const target=nodeEl.get(issue.nodeIds[0]),p=target?pos.get(issue.nodeIds[0]):null;
    const annotation=moddle.create('bpmn:TextAnnotation',{id:'Issue_'+(i+1),text:'Нужно уточнить: '+issue.message});
    const bounds={x:dimensions.width+70,y:MARGIN+i*155,width:310,height:130};
    artifacts.push(annotation);
    planeElements.push(moddle.create('bpmndi:BPMNShape',{id:'Shape_Issue_'+(i+1),bpmnElement:annotation,bounds:moddle.create('dc:Bounds',bounds)}));
    if(target) {
      const association=moddle.create('bpmn:Association',{id:'Issue_Association_'+(i+1),sourceRef:target,targetRef:annotation,associationDirection:'None'});
      artifacts.push(association);
      planeElements.push(moddle.create('bpmndi:BPMNEdge',{id:'Shape_Issue_Association_'+(i+1),bpmnElement:association,waypoint:[{x:p.x+p.width,y:p.y+p.height/2},{x:bounds.x,y:bounds.y+40}].map(point=>moddle.create('dc:Point',point))}));
    }
  });
  processEl.artifacts=artifacts;

  for (const n of graph.nodes) {
    const p = pos.get(n.id);
    const shape = moddle.create('bpmndi:BPMNShape', {
      id: 'Shape_' + nodeEl.get(n.id).id,
      bpmnElement: nodeEl.get(n.id),
      bounds: moddle.create('dc:Bounds', { x: Math.round(p.x), y: Math.round(p.y), width: p.width, height: p.height })
    });
    if (n.type.includes('Gateway')) shape.isMarkerVisible = true;
    planeElements.push(shape);
  }

  graph.edges.forEach((e, i) => {
    const pts = waypoints.get('e' + i) || [];
    const edge = moddle.create('bpmndi:BPMNEdge', {
      id: 'Edge_' + i,
      bpmnElement: flowById.get(e.from + '->' + e.to),
      waypoint: pts.map(p => moddle.create('dc:Point', { x: Math.round(p.x), y: Math.round(p.y) }))
    });
    if (e.label) {
      const mid = pts.length ? pts[Math.floor(pts.length / 2)] : { x: 0, y: 0 };
      const w = Math.max(30, e.label.length * 8 + 10);
      edge.BPMNLabel = moddle.create('bpmndi:BPMNLabel', {
        bounds: moddle.create('dc:Bounds', { x: Math.round(mid.x - w / 2), y: Math.round(mid.y - 20), width: w, height: 14 })
      });
    }
    planeElements.push(edge);
  });

  plane.planeElement = planeElements;

  const diagram = moddle.create('bpmndi:BPMNDiagram', {
    id: 'BPMNDiagram_1',
    name: graph.name,
    plane
  });

  const definitions = moddle.create('bpmn:Definitions', {
    id: 'Definitions_1',
    targetNamespace: 'http://bpmn.io/schema/bpmn',
    exporter: 'BPMN-Компилятор (ИИ-ассистенты для энергетики)',
    exporterVersion: require('../../package.json').version,
    rootElements: [processEl,collaboration],
    diagrams: [diagram]
  });

  const { xml } = await toXML(moddle, definitions, { format: true });
  return xml;
}

/** Компиляция полного цикла: граф -> валидный XML + обратная проверка парсингом. */
async function compile(graph) {
  const dimensions = await layout(graph);
  const xml = await buildXml(graph, dimensions.pos, dimensions.waypoints, dimensions);

  // Проверка совместимости метамодели, не эквивалент XSD-валидации.
  const moddle = new BpmnModdle();
  const parsed = await fromXML(moddle, xml);
  if (parsed.warnings.length) throw new Error('BPMN содержит предупреждения парсинга: ' + parsed.warnings.map(w=>w.message).join('; '));

  return { xml };
}

module.exports = { compile, layout, SIZES, escapeXmlAttr };
