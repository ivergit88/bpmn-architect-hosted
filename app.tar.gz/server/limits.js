'use strict';
// Общий бюджет сервиса, а не доверие заголовкам IP из публичного туннеля.
function createLimiter({limit=30,windowMs=60000,maxConcurrent=3}={}) {
  let since=Date.now(),count=0,active=0;
  return (req,res,next)=>{
    if(req.method!=='POST'||!req.path.startsWith('/api/')) return next();
    const now=Date.now();if(now-since>=windowMs){since=now;count=0;}
    if(count>=limit||active>=maxConcurrent) {
      res.setHeader('Retry-After',Math.max(1,Math.ceil((windowMs-(now-since))/1000)));
      return res.status(429).json({error:'Лимит запросов сервиса. Повторите через минуту.'});
    }
    count++;active++;
    let finished=false;
    const release=()=>{if(!finished){finished=true;active--;}};
    res.once('finish',release);res.once('close',release);
    next();
  };
}
module.exports={createLimiter};
