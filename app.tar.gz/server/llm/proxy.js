'use strict';

// Optional server-side route; browser requests and credentials are unaffected.
function configureProxy(env = process.env, http = require('node:http')) {
  const value = (env.LLM_PROXY_URL || '').trim();
  if (!value) return false;
  let url;
  try { url = new URL(value); } catch { throw new Error('LLM_PROXY_URL must be an HTTP(S) URL'); }
  if (!['http:', 'https:'].includes(url.protocol)) {
    throw new Error('LLM_PROXY_URL must be an HTTP(S) URL');
  }
  if (typeof http.setGlobalProxyFromEnv !== 'function') {
    throw new Error('LLM_PROXY_URL requires Node.js 24 with setGlobalProxyFromEnv support');
  }
  return http.setGlobalProxyFromEnv({
    HTTP_PROXY: url.href, HTTPS_PROXY: url.href, NO_PROXY: 'localhost,127.0.0.1,::1'
  });
}
module.exports = { configureProxy };
