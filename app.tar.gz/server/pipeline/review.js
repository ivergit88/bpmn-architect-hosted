'use strict';
const {finalChecks}=require('./verify');

function inspect(graph) {
  const g=structuredClone(graph);
  const issues=[...(g.issues||[])];
  for (const issue of issues) {
    const gateway=g.nodes.find(n=>n.id===issue.from);
    // Модель иногда называет отсутствующую ветвь обычным разрывом.
    // Такой вопрос нельзя закрыть прямой стрелкой в обход условия.
    if(issue.kind==='flow-gap'&&gateway?.type==='exclusiveGateway'&&gateway.label&&g.edges.filter(e=>e.from===gateway.id).length===1) {
      issue.kind='missing-branch';
    }
  }
  for(const issue of issues) if(issue.kind==='flow-gap'&&issue.from&&issue.to) {
    g.edges=g.edges.filter(e=>e.from!==issue.from||e.to!==issue.to);
  }
  const add=(issue)=>{
    if(issues.some(i=>i.kind===issue.kind&&JSON.stringify(i.nodeIds)===JSON.stringify(issue.nodeIds))) return;
    let index=1; while(issues.some(i=>i.id==='review'+index)) index++;
    issues.push({id:'review'+index,...issue});
  };
  for(const edge of [...g.edges]) {
    const a=g.nodes.find(n=>n.id===edge.from),b=g.nodes.find(n=>n.id===edge.to);
    const confirmed=(g.clarifications||[]).some(c=>c.decision==='connect'&&c.from===a.id&&c.to===b.id);
    const externalInput=(g.messages||[]).some(m=>m.to===b.id&&(g.participants||[]).some(p=>p.id===m.from));
    if(a.outputs?.length&&b.inputs?.length&&!a.outputs.some(x=>b.inputs.some(y=>x.toLowerCase()===y.toLowerCase()))&&!confirmed&&!externalInput) {
      g.edges=g.edges.filter(e=>e!==edge);
      add({kind:'document-mismatch',nodeIds:[a.id,b.id],from:a.id,to:b.id,
        message:`Выход «${a.outputs.join(', ')}» не совпадает с входом «${b.inputs.join(', ')}». Связь не подтверждена.`,
        question:'Какой документ передаётся между этими действиями? Подтвердите независимость документов или исправьте описание.'});
    }
  }
  for(const n of g.nodes.filter(n=>n.type==='task')) {
    if(n.lane==='Участник процесса') add({kind:'missing-actor',nodeIds:[n.id],message:'Не указан исполнитель: '+n.label,question:'Кто выполняет действие «'+n.label+'»?',source:n.source||''});
    if(g.sourceText&&n.source&&!g.sourceText.replace(/\s+/g,' ').includes(n.source)) add({kind:'evidence',nodeIds:[n.id],message:'Исходная фраза не найдена в описании: '+n.label,question:'Подтвердите это действие или уточните исходный текст.'});
  }
  const checks=finalChecks(g);
  // Включённый черновик с фрагментами анализируем, не достраивая его.
  if(g.draft&&!issues.length&&checks.some(c=>!c.ok)) add({kind:'structure',nodeIds:g.nodes.filter(n=>n.type==='task').map(n=>n.id),message:'Описание содержит несвязанные или незавершённые фрагменты',question:'Какие переходы и завершения явно предусмотрены? Уточните описание или соедините элементы вручную.'});
  g.issues=issues;
  g.draft=issues.length>0||checks.some(c=>!c.ok);
  return {graph:g,issues,checks,status:g.draft?'draft':'ready'};
}
module.exports={inspect};
