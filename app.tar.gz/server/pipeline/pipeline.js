'use strict';

/**
 * Оркестратор: (LLM | эвристика) -> normalize -> verify&repair -> compile.
 * Возвращает граф, XML и полный отчёт для UI/жюри.
 */

const { normalizeGraph } = require('./graph');
const { verifyAndRepair, finalChecks } = require('./verify');
const { compile } = require('./compile');
const { parseProcessText } = require('../llm/fallback');
const provider = require('../llm/provider');
const {inspect}=require('./review');

const SIMPLE_EDIT_OPS = [
  {
    re: /(?:удали|убери|исключи)\s+(?:задачу\s+)?(.+)/i,
    apply: (g, m) => {
      const node = findByLabel(g, m[1]);
      if (!node) return false;
      if (node.type !== 'task') throw Object.assign(new Error('Удалять текстом можно только задачи; шлюзы и события изменяйте в редакторе'), {status:422});
      const outs = g.edges.filter(e => e.from === node.id);
      const ins = g.edges.filter(e => e.to === node.id);
      g.edges = g.edges.filter(e => e.from !== node.id && e.to !== node.id);
      for (const i of ins) for (const o of outs) if (i.from !== o.to) g.edges.push({ from: i.from, to: o.to, label: o.label || i.label || '' });
      g.nodes = g.nodes.filter(n => n.id !== node.id);
      return true;
    }
  },
  {
    re: /(?:добавь|вставь|добавить)\s+(?:задачу\s+)?(.+?)\s+(?:после|следом за)\s+(.+)/i,
    apply: (g, m) => {
      const after = findByLabel(g, m[2]);
      if (!after) return false;
      if (after.type !== 'task' && after.type !== 'startEvent') throw Object.assign(new Error('Добавлять задачу можно после задачи или стартового события'), {status:422});
      const outs = g.edges.filter(e => e.from === after.id);
      const node = { id: newId(g), type: 'task', label: cap(m[1].replace(/^[«"']|[»"']$/g, '')), lane: after.lane };
      g.nodes.push(node);
      g.edges = g.edges.filter(e => e.from !== after.id);
      g.edges.push({ from: after.id, to: node.id, label: '' });
      for (const o of outs) g.edges.push({ from: node.id, to: o.to, label: o.label });
      return true;
    }
  },
  {
    re: /(?:переименуй|переименовать)\s+(.+?)\s+в\s+(.+)/i,
    apply: (g, m) => {
      const node = findByLabel(g, m[1]);
      if (!node) return false;
      node.label = cap(m[2]);
      return true;
    }
  }
];

function newId(g) {
  let i = g.nodes.length + 1;
  const ids = new Set(g.nodes.map(n => n.id));
  while (ids.has('n' + i)) i++;
  return 'n' + i;
}
function cap(s) { s = s.trim(); return s.charAt(0).toUpperCase() + s.slice(1); }
function findByLabel(g, needle) {
  const q = String(needle).trim().toLowerCase().replace(/^[«"']|[»"'.?!]+$/g, '');
  if (!q) return null;
  const exact = g.nodes.filter(n => n.label.toLowerCase() === q);
  const matches = exact.length ? exact : g.nodes.filter(n => n.label.toLowerCase().includes(q) || (n.label.length > 2 && q.includes(n.label.toLowerCase())));
  if (matches.length > 1) throw Object.assign(new Error('Неоднозначное название: укажите полное уникальное название задачи или переименуйте её в редакторе'), {status:422});
  return matches[0] || null;
}

function fallbackEdit(graph, instruction) {
  const g = JSON.parse(JSON.stringify(graph));
  for (const op of SIMPLE_EDIT_OPS) {
    const m = instruction.match(op.re);
    if (m) {
      const changed = op.apply(g, m);
      if (changed) return { graph: g, via: 'фолбэк-редактор' };
    }
  }
  const err = new Error('Фолбэк-редактор понял только: «удали X», «добавь X после Y», «переименуй X в Y». Для произвольных правок настрой LLM.');
  err.status = 422;
  throw err;
}

async function runPipeline({ text, graph, instruction, llm, mode }) {
  const t0 = Date.now();
  const report = { provider: null, model: null, fallbackReason: null, repairs: [], warnings: [], repairsNote: '' };

  let rawGraph;
  const cfg = provider.resolveConfig(llm);

  if (mode === 'compile') {
    rawGraph = normalizeGraph(graph);
    report.provider = 'compile';
  } else if (mode === 'edit') {
    if (cfg.ok) {
      try {
        rawGraph = await provider.editGraph(cfg, normalizeGraph(graph), instruction);
        report.provider = 'llm'; report.model = cfg.model;
      } catch (e) {
        report.fallbackReason = 'LLM недоступен: ' + e.message;
        const r = fallbackEdit(normalizeGraph(graph), instruction);
        rawGraph = r.graph; report.provider = 'heuristic';
      }
    } else {
      const r = fallbackEdit(normalizeGraph(graph), instruction);
      rawGraph = r.graph; report.provider = 'heuristic';
      report.fallbackReason = 'LLM не настроен (проверьте URL, модель и ключ в серверном .env)';
    }
  } else {
    if (cfg.ok) {
      try {
        rawGraph = await provider.generateGraph(cfg, text);
        report.provider = 'llm'; report.model = cfg.model;
      } catch (e) {
        report.fallbackReason = 'LLM недоступен: ' + e.message;
        rawGraph = parseProcessText(text);
        report.provider = 'heuristic';
      }
    } else {
      rawGraph = parseProcessText(text);
      report.provider = 'heuristic';
      report.fallbackReason = 'LLM не настроен (проверьте URL, модель и ключ в серверном .env)';
    }
  }

  if (mode !== 'edit' && mode !== 'compile') rawGraph.sourceText = text;
  const normalized = normalizeGraph(rawGraph);
  const examined=inspect(normalized);
  const { graph: repaired, repairs, warnings, checks } = examined.status==='draft'
    ? {graph:examined.graph,repairs:[],warnings:['Черновик: неопределённости не исправляются придуманными переходами.'],checks:examined.checks}
    : verifyAndRepair(examined.graph);
  report.repairs = repairs;
  report.warnings = warnings;

  ensureEventChecks(checks);
  if(examined.status!=='draft') ensureChecks(checks);
  const { xml } = await compile(repaired);
  report.checks = checks;
  report.status=examined.status;
  report.issues=examined.issues;
  report.clarifications=repaired.clarifications||[];
  report.validXml = true;
  report.validation = 'bpmn-moddle round-trip; XSD проверяется отдельно через npm run validate:xsd';
  if (report.provider === 'heuristic') report.warnings.push('Эвристический режим: проверьте участников, полноту действий и смысл ветвлений. Для произвольного текста подключите LLM.');
  report.ms = Date.now() - t0;
  report.stats = {
    nodes: repaired.nodes.length,
    edges: repaired.edges.length,
    tasks: repaired.nodes.filter(n => n.type === 'task').length,
    gateways: repaired.nodes.filter(n => n.type.includes('Gateway')).length
  };

  return { graph: repaired, xml, report };
}

async function recompile(graphRaw) {
  const t0 = Date.now();
  const normalized = normalizeGraph(graphRaw);
  const examined=inspect(normalized);
  const acceptDraft=normalized.draft||examined.issues.some(i=>i.kind==='document-mismatch');
  const { graph: repaired, repairs, warnings, checks } = examined.status==='draft'&&acceptDraft
    ? {graph:examined.graph,repairs:[],warnings:['Открыт черновик; связи не достраивались.'],checks:examined.checks}
    : verifyAndRepair(examined.graph);
  ensureEventChecks(checks);
  if(!acceptDraft) ensureChecks(checks);
  const { xml } = await compile(repaired);
  return {
    graph: repaired,
    xml,
    report: {
      provider: 'compile',
      model: null,
      fallbackReason: null,
      repairs, warnings, checks,
      status:examined.status,issues:examined.issues,clarifications:repaired.clarifications||[],
      validXml: true,
      ms: Date.now() - t0,
      stats: {
        nodes: repaired.nodes.length,
        edges: repaired.edges.length,
        tasks: repaired.nodes.filter(n => n.type === 'task').length,
        gateways: repaired.nodes.filter(n => n.type.includes('Gateway')).length
      }
    }
  };
}

async function clarify({graph,issueId,answer,decision,llm}) {
  const g=normalizeGraph(graph);
  const issue=g.issues.find(i=>i.id===issueId);
  if(!issue) throw Object.assign(new Error('Вопрос уже решён или не найден. Обновите отчёт.'),{status:422});
  const reply=String(answer||'').trim();
  if(!reply||reply.length>2000) throw Object.assign(new Error('Введите ответ до 2000 символов'),{status:400});
  if(decision==='connect') {
    if(!['flow-gap','document-mismatch'].includes(issue.kind)||!issue.from||!issue.to) throw Object.assign(new Error('Для этого вопроса нельзя подтвердить связь'),{status:422});
    if(!g.edges.some(e=>e.from===issue.from&&e.to===issue.to)) g.edges.push({from:issue.from,to:issue.to,label:''});
  } else if(decision==='actor') {
    if(issue.kind!=='missing-actor') throw Object.assign(new Error('Этот вопрос не об исполнителе'),{status:422});
    for(const n of g.nodes) if(issue.nodeIds.includes(n.id)) n.lane=reply;
    if(!g.lanes.includes(reply)) g.lanes.push(reply);
  } else if(decision==='branch') {
    if(issue.kind!=='missing-branch') throw Object.assign(new Error('Этот вопрос не об отрицательной ветви'),{status:422});
    const part=parseProcessText(reply);
    if(part.issues?.length||part.nodes.some(n=>n.type.includes('Gateway'))||part.messages?.length||part.participants?.length||!part.nodes.some(n=>n.type==='task')) throw Object.assign(new Error('Укажите явное действие с исполнителем для отрицательной ветви. Сложную ветку исправьте в исходном тексте.'),{status:422});
    let last=issue.from;
    for(const n of part.nodes.filter(n=>n.type==='task')) {
      const id=newId(g); g.nodes.push({...n,id});
      g.edges.push({from:last,to:id,label:last===issue.from?'нет':''}); last=id;
    }
    const endsExplicitly=/заверш|конец/i.test(reply);
    if(endsExplicitly) {
      const id=newId(g);g.nodes.push({id,type:'endEvent',label:'Конец',lane:g.nodes.find(n=>n.id===last).lane});g.edges.push({from:last,to:id,label:''});
      // Одновходный join больше не является шлюзом слияния.
      const merge=g.nodes.find(n=>n.id===issue.to);
      if(merge&&g.edges.filter(e=>e.to===merge.id).length===1) {
        const incoming=g.edges.find(e=>e.to===merge.id),outgoing=g.edges.find(e=>e.from===merge.id);
        if(outgoing) g.edges.push({from:incoming.from,to:outgoing.to,label:incoming.label});
        g.edges=g.edges.filter(e=>e.from!==merge.id&&e.to!==merge.id);g.nodes=g.nodes.filter(n=>n.id!==merge.id);
      }
    } else g.edges.push({from:last,to:issue.to,label:''});
  } else if(decision==='return') {
    if(issue.kind!=='missing-return'||!issue.from) throw Object.assign(new Error('Этот вопрос не о возврате'),{status:422});
    const target=findByLabel(g,reply);
    if(!target||target.type!=='task') throw Object.assign(new Error('Укажите точное уникальное название задачи возврата'),{status:422});
    g.edges.push({from:issue.from,to:target.id,label:g.nodes.find(n=>n.id===issue.from).type.includes('Gateway')?'нет':''});
  } else {
    const cfg=provider.resolveConfig(llm);
    if(!cfg.ok) throw Object.assign(new Error('Для свободного ответа подключите LLM или исправьте исходное описание и постройте схему заново.'),{status:422});
    const updated=await provider.editGraph(cfg,g,'Уточнение к вопросу '+issue.question+': '+reply+'. Исправь только эту неопределённость; остальные сохрани.');
    updated.sourceText=(g.sourceText||'')+'\nУточнение: '+reply;
    updated.clarifications=[...g.clarifications,{issueId,question:issue.question,answer:reply,decision:'llm'}];
    return runPipeline({graph:updated,mode:'compile'});
  }
  g.issues=g.issues.filter(i=>i.id!==issueId);
  g.clarifications.push({issueId,question:issue.question,answer:reply,decision,from:issue.from,to:issue.to});
  g.sourceText=(g.sourceText||'')+'\nУточнение: '+reply;
  g.draft=g.issues.length>0;
  return runPipeline({graph:g,mode:'compile'});
}

function ensureChecks(checks) {
  const bad = checks.filter(c => !c.ok);
  if (bad.length) throw Object.assign(new Error('Структурные ошибки: ' + bad.map(c => c.name + ' (' + c.detail + ')').join('; ')), {status:422, checks});
}
function ensureEventChecks(checks) {
  ensureChecks(checks.filter(c=>c.name==='События имеют корректные переходы'));
}
module.exports = { runPipeline, recompile, finalChecks, clarify };
