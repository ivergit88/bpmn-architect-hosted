'use strict';

/**
 * Промежуточное представление (IR) процесса — типизированный JSON-граф.
 * Именно его пишет LLM (или эвристический парсер), а компилятор переводит
 * в валидный BPMN 2.0 XML. Нормализация приводит любой вход к строгой схеме.
 */

const NODE_TYPES = ['startEvent', 'task', 'exclusiveGateway', 'parallelGateway', 'inclusiveGateway', 'endEvent'];

const invalid = message => Object.assign(new Error(message), {status:422});

function normalizeLabel(label, max = 80) {
  const s = String(label == null ? '' : label).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '').replace(/\s+/g, ' ').trim();
  return s.length > max ? s.slice(0, max - 1) + '…' : s;
}

/**
 * Приводит произвольный вход (от LLM или парсера) к строгой IR.
 * Бросает Error с понятным описанием, если вход не граф вообще.
 */
function normalizeGraph(raw) {
  if (!raw || typeof raw !== 'object') throw invalid('Ответ модели — не JSON-объект');
  const nodesIn = raw.nodes;
  const edgesIn = raw.edges;
  if (!Array.isArray(nodesIn) || nodesIn.length === 0) throw invalid('Нет массива nodes');
  if (!Array.isArray(edgesIn)) throw invalid('Нет массива edges');

  if (nodesIn.length > 200 || edgesIn.length > 500) throw invalid('Граф слишком большой: максимум 200 узлов и 500 переходов');
  const used = new Set();
  const nodes = [];
  for (const n of nodesIn) {
    if (!n || typeof n !== 'object') throw invalid('Некорректный узел');
    let type = String(n.type || 'task');
    if (!NODE_TYPES.includes(type)) throw invalid('Неизвестный тип узла: ' + type);
    let id = String(n.id || '').trim();
    if (used.has(id)) throw invalid('Повторный id узла: ' + id);
    if (!id) throw invalid('Узел без id');
    used.add(id);
    nodes.push({ id, type, label: normalizeLabel(n.label ?? defaultLabel(type), 200), lane: normalizeLabel(n.lane || n.actor || '', 80),
      ...(n.source ? {source:normalizeLabel(n.source,1200)} : {}),
      ...(Array.isArray(n.inputs) ? {inputs:n.inputs.slice(0,10).map(s=>normalizeLabel(s,120))} : {}),
      ...(Array.isArray(n.outputs) ? {outputs:n.outputs.slice(0,10).map(s=>normalizeLabel(s,120))} : {}) });
  }
  if (nodes.length === 0) throw invalid('Граф не содержит узлов');

  const byId = new Map(nodes.map(n => [n.id, n]));
  const edges = [];
  const seen = new Set();
  for (const e of edgesIn) {
    if (!e || typeof e !== 'object') throw invalid('Некорректный переход');
    const from = String(e.from || e.source || '').trim();
    const to = String(e.to || e.target || '').trim();
    if (!byId.has(from) || !byId.has(to)) throw invalid('Переход ссылается на отсутствующий узел');
    const key = from + '->' + to;
    if (seen.has(key)) throw invalid('Повторный переход: ' + key);
    seen.add(key);
    edges.push({ from, to, label: normalizeLabel(e.label || '', 100) });
  }
  if (edges.length === 0 && !raw.draft && !raw.issues?.length) throw invalid('Граф не содержит связей');

  const name = normalizeLabel(raw.name || 'Процесс', 120);
  const lanes = [];
  for (const lane of Array.isArray(raw.lanes) ? raw.lanes : []) {
    const label = normalizeLabel(typeof lane === 'string' ? lane : lane && (lane.name || lane.label), 80);
    if (label && !lanes.includes(label)) lanes.push(label);
  }
  for (const n of nodes) if (n.lane && !lanes.includes(n.lane)) lanes.push(n.lane);
  if (nodes.some(n => !n.lane)) lanes.push('Участник процесса');
  for (const n of nodes) n.lane ||= 'Участник процесса';
  const issues=(Array.isArray(raw.issues)?raw.issues:[]).slice(0,50).map((i,index)=>({
    id:normalizeLabel(i.id||'issue'+(index+1),80),kind:normalizeLabel(i.kind||'logic',80),
    nodeIds:(Array.isArray(i.nodeIds)?i.nodeIds:[]).map(String).filter(id=>byId.has(id)),
    ...(byId.has(String(i.from))?{from:String(i.from)}:{}),...(byId.has(String(i.to))?{to:String(i.to)}:{}),
    message:normalizeLabel(i.message||'Нужно уточнить логику',700),question:normalizeLabel(i.question||'Как должен продолжаться процесс?',700),
    ...(i.source?{source:normalizeLabel(i.source,1200)}:{})
  }));
  if (new Set(issues.map(i=>i.id)).size!==issues.length) throw invalid('Повторный id неопределённости');
  const participants=(Array.isArray(raw.participants)?raw.participants:[]).slice(0,20).map((p,i)=>({id:String(p.id||'external'+(i+1)),name:normalizeLabel(p.name||'Внешний участник',100)}));
  const participantsById=new Map(participants.map(p=>[p.id,p]));
  if (participantsById.size!==participants.length||participants.some(p=>byId.has(p.id))) throw invalid('Повторный id участника');
  const messages=(Array.isArray(raw.messages)?raw.messages:[]).slice(0,100).map(m=>{
    const from=String(m.from||''),to=String(m.to||'');
    if (!(participantsById.has(from)&&byId.has(to))&&!(byId.has(from)&&participantsById.has(to))) throw invalid('Сообщение должно связывать задачу/событие и внешний пул');
    if ([from,to].some(id=>byId.has(id)&&byId.get(id).type.includes('Gateway'))) throw invalid('Сообщение не может связываться со шлюзом');
    return {from,to,label:normalizeLabel(m.label||'',120),...(m.source?{source:normalizeLabel(m.source,1200)}:{})};
  });
  const clarifications=(Array.isArray(raw.clarifications)?raw.clarifications:[]).slice(-30).map(c=>({
    issueId:normalizeLabel(c.issueId,80),question:normalizeLabel(c.question,700),answer:normalizeLabel(c.answer,2000),decision:normalizeLabel(c.decision,80),
    ...(c.from?{from:String(c.from)}:{}),...(c.to?{to:String(c.to)}:{})
  }));
  return { name, lanes: [...new Set(lanes)], nodes, edges,
    ...(raw.draft||issues.length?{draft:true}:{}),issues,participants,messages,clarifications,
    ...(raw.sourceText?{sourceText:String(raw.sourceText).slice(0,90000)}:{}) };
}

function defaultLabel(type) {
  return { startEvent: 'Начало', endEvent: 'Конец', task: 'Задача', exclusiveGateway: 'Условие?', parallelGateway: 'И/И' }[type] || '';
}

module.exports = { normalizeGraph, NODE_TYPES, defaultLabel };
