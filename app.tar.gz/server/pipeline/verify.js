'use strict';

function indexGraph(graph) {
  const byId = new Map(graph.nodes.map(n => [n.id, n]));
  const out = new Map(graph.nodes.map(n => [n.id, []]));
  const inMap = new Map(graph.nodes.map(n => [n.id, []]));
  for (const edge of graph.edges) if (byId.has(edge.from) && byId.has(edge.to)) {
    out.get(edge.from).push(edge); inMap.get(edge.to).push(edge);
  }
  return { byId, out, inMap };
}
function reachable(ids, links, direction) {
  const seen = new Set(ids), stack = [...ids];
  while (stack.length) {
    const id = stack.pop();
    for (const edge of links.get(id) || []) {
      const next = edge[direction];
      if (!seen.has(next)) { seen.add(next); stack.push(next); }
    }
  }
  return seen;
}
// Только однозначные дополнения. Не придумываем связи и условия.
function verifyAndRepair(raw) {
  const graph = structuredClone(raw), repairs = [], warnings = [];
  let counter = 0;
  const add = (type, label, lane) => {
    let id;
    do { id = 'r' + ++counter; } while (graph.nodes.some(n => n.id === id));
    const node = { id, type, label, lane: lane || graph.lanes[0] };
    graph.nodes.push(node); return node;
  };
  let idx = indexGraph(graph);
  const starts = graph.nodes.filter(n => n.type === 'startEvent');
  const roots = graph.nodes.filter(n => n.type !== 'endEvent' && !idx.inMap.get(n.id).length);
  if (!starts.length && roots.length === 1) {
    const start = add('startEvent', 'Начало', roots[0].lane);
    graph.edges.unshift({from:start.id,to:roots[0].id,label:''});
    repairs.push('Добавлено начало перед единственным корнем графа');
  }
  idx = indexGraph(graph);
  const leaves = graph.nodes.filter(n => n.type !== 'endEvent' && !idx.out.get(n.id).length);
  for (const leaf of leaves) {
    const end = add('endEvent', 'Конец', leaf.lane);
    graph.edges.push({from:leaf.id,to:end.id,label:''});
    repairs.push('Добавлено завершение после «' + leaf.label + '»');
  }
  if (!graph.nodes.some(n => n.type === 'endEvent')) warnings.push('В графе нет выхода из цикла к завершению');
  if (repairs.length) warnings.push('Автодополнения требуют подтверждения аналитиком');
  return {graph, repairs, warnings, checks:finalChecks(graph)};
}
function finalChecks(graph) {
  const {byId,out,inMap} = indexGraph(graph), checks = [];
  const push = (name, ok, detail) => checks.push({name,ok,detail});
  const starts = graph.nodes.filter(n=>n.type==='startEvent');
  const ends = graph.nodes.filter(n=>n.type==='endEvent');
  push('Единственное стартовое событие', starts.length===1, 'найдено: ' + starts.length);
  push('Есть конечное событие', ends.length>0, 'найдено: ' + ends.length);
  const badEdges = graph.edges.filter(e=>!byId.has(e.from)||!byId.has(e.to));
  push('Нет висячих переходов', !badEdges.length, 'висячих: ' + badEdges.length);
  const leaves = graph.nodes.filter(n=>n.type!=='endEvent'&&!out.get(n.id).length);
  push('Нет тупиковых узлов', !leaves.length, 'тупиков: ' + leaves.length);
  const fromStart = reachable(starts.map(n=>n.id),out,'to');
  push('Все узлы достижимы от старта', fromStart.size===graph.nodes.length, 'недостижимых: ' + (graph.nodes.length-fromStart.size));
  const toEnd = reachable(ends.map(n=>n.id),inMap,'from');
  push('Из каждого узла есть путь к завершению', toEnd.size===graph.nodes.length, 'без выхода: ' + (graph.nodes.length-toEnd.size));
  const badEvents = graph.nodes.filter(n=>(n.type==='startEvent'&&inMap.get(n.id).length)||(n.type==='endEvent'&&out.get(n.id).length));
  push('События имеют корректные переходы', !badEvents.length, 'ошибок: ' + badEvents.length);
  const badGateways = graph.nodes.filter(n=>n.type.includes('Gateway') && !((inMap.get(n.id).length===1&&out.get(n.id).length>=2)||(inMap.get(n.id).length>=2&&out.get(n.id).length===1)));
  push('Шлюзы согласованы (split/join)', !badGateways.length, 'ошибок: ' + badGateways.length);
  const unlabeled = graph.edges.filter(e=>byId.get(e.from)?.type==='exclusiveGateway'&&out.get(e.from).length>1&&!e.label);
  push('Ветви условий подписаны (да/нет)', !unlabeled.length, 'неподписанных: ' + unlabeled.length);
  const implicitSplits = graph.nodes.filter(n=>!n.type.includes('Gateway')&&out.get(n.id).length>1);
  push('Ветвления заданы явными шлюзами', !implicitSplits.length, 'неявных: ' + implicitSplits.length);
  return checks;
}
module.exports = {indexGraph, verifyAndRepair, finalChecks};
