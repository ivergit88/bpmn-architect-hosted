'use strict';

/* BPMN-Компилятор — клиент. Диаграмма рендерится bpmn-js из нашего XML:
   Структурная проверка и XSD-валидация выполняются отдельно от рендера. */

const $ = (id) => document.getElementById(id);

const state = {
  graph: null,
  xml: null,
  viewer: null,
  edits: 0,
  busy: false,
  importing: false,
  clientLlmConfigAllowed: false
};

/* ---------- bpmn-js viewer ---------- */

function initViewer() {
  state.viewer = new BpmnJS({ container: '#canvas' });
  $('zoomFit').onclick = () => { state.viewer.get('canvas').resized(); state.viewer.get('canvas').zoom('fit-viewport'); };
  $('zoomIn').onclick = () => state.viewer.get('canvas').zoom(state.viewer.get('canvas').zoom() * 1.2);
  $('zoomOut').onclick = () => state.viewer.get('canvas').zoom(state.viewer.get('canvas').zoom() / 1.2);
  state.viewer.on('commandStack.changed', () => {
    if (state.importing || !state.xml) return;
    $('reportCard').hidden = true;
    $('reviewCard').hidden = true;
    showStatus('Диаграмма изменена вручную. Экспорт сохранит изменения; при текстовой правке структура проверяется заново.');
  });
  state.viewer.on('selection.changed',event=>{
    const bo=event.newSelection?.[0]?.businessObject;
    const meta=readMetadata(bo);
    $('sourceCard').hidden=!bo||!meta.source;
    if(!bo||!meta.source) return;
    $('sourceTitle').textContent=bo.name||'Элемент процесса';
    $('sourceQuote').textContent=meta.source;
    $('sourceDocuments').textContent=[meta.inputs?.length?'Вход: '+meta.inputs.join(', '):'',meta.outputs?.length?'Выход: '+meta.outputs.join(', '):''].filter(Boolean).join(' · ');
  });
}

async function renderXml(xml, title) {
  // Снимок текущей модели включает ручные правки, в отличие от state.xml.
  const previous = state.xml ? (await state.viewer.saveXML({format:true})).xml : null;
  hideEmpty();
  try {
    state.importing = true;
    const { warnings } = await state.viewer.importXML(xml);
    state.viewer.get('canvas').zoom('fit-viewport', 'auto');
    $('canvasTitle').textContent = title || 'Диаграмма';
    state.xml = xml;
    if (warnings.length) showStatus('При открытии BPMN обнаружены предупреждения: ' + warnings.map(w=>w.message).join('; '), 'error');
  } catch (err) {
    if (previous) {
      try {
        await state.viewer.importXML(previous);
        state.viewer.get('canvas').zoom('fit-viewport', 'auto');
        state.xml = previous;
      } catch {
        state.xml = null;
        state.graph = null;
        $('canvasTitle').textContent = 'Не удалось восстановить диаграмму';
      }
    }
    showStatus('Не удалось отрендерить XML: ' + (err.message || err), 'error');
    throw err;
  } finally {
    state.importing = false;
  }
}

function hideEmpty() {
  const empty = document.querySelector('.canvas-empty');
  if (empty) empty.remove();
}

/* ---------- API ---------- */

function llmConfig() {
  if (!state.clientLlmConfigAllowed) return undefined;
  return {
    baseUrl: localStorage.getItem('cfg.baseUrl') || '',
    model: localStorage.getItem('cfg.model') || '',
    apiKey: sessionStorage.getItem('cfg.apiKey') || ''
  };
}

async function api(path, body) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...body, llm: llmConfig() })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || ('HTTP ' + res.status));
  return data;
}

/* ---------- Отчёт ---------- */

function renderReport(report) {
  $('reportCard').hidden = false;
  const s = report.stats || {};
  $('reportStats').innerHTML = `
    <div class="stat"><b>${s.nodes ?? '–'}</b><span>узлов</span></div>
    <div class="stat"><b>${s.tasks ?? '–'}</b><span>задач</span></div>
    <div class="stat"><b>${s.gateways ?? '–'}</b><span>шлюзов</span></div>
    <div class="stat"><b>${report.ms ?? '–'} мс</b><span>компиляция</span></div>`;
  $('reportChecks').innerHTML = (report.checks || [])
    .map(c => `<div class="check ${c.ok ? 'ok' : 'fail'}" title="${escapeHtml(c.detail || '')}"><span>${escapeHtml(c.name)}</span></div>`)
    .join('');
  const rep = report.repairs || [];
  const warn = report.warnings || [];
  $('reportRepairs').innerHTML =
    (rep.length ? `<div>Автодополнения (${rep.length}):</div>` + rep.map(r => `<div>${escapeHtml(r)}</div>`).join('') : '') +
    (warn.length ? warn.map(w => `<div style="color:var(--muted)">⚠ ${escapeHtml(w)}</div>`).join('') : '');
  renderReview(report);
}

function readMetadata(bo) {
  const text=(bo?.documentation||[]).find(d=>d.text?.startsWith('BPMN-Architect: '))?.text;
  try {return text?JSON.parse(text.slice('BPMN-Architect: '.length)):{};} catch {return {};}
}
function renderReview(report) {
  let graph;
  try {graph=currentGraph();} catch { $('reviewCard').hidden=true;return; }
  const issues=graph.issues||[];
  $('reviewCard').hidden=!issues.length&&!graph.clarifications?.length;
  $('reviewSummary').textContent=issues.length?`Черновик. Вопросов: ${issues.length}. Неподтверждённые переходы не дорисованы.`:'Уточнения применены. Проверьте результат.';
  $('reviewQuestions').replaceChildren();
  const canvas=state.viewer.get('canvas');
  for(const n of graph.nodes) canvas.removeMarker(n.id,'needs-review');
  for(const issue of issues) {
    for(const id of issue.nodeIds) if(state.viewer.get('elementRegistry').get(id)) canvas.addMarker(id,'needs-review');
    const card=document.createElement('div');card.className='question';
    const detail=document.createElement('p');detail.className='issue-detail';detail.textContent=issue.message;
    const question=document.createElement('p');question.textContent=issue.question;
    const answer=document.createElement('input');answer.maxLength=2000;answer.placeholder=issue.kind==='missing-actor'?'Исполнитель':issue.kind==='missing-return'?'Точное название задачи возврата':'Ваш ответ';answer.setAttribute('aria-label',issue.question);
    card.append(detail,question,answer);
    const choices=issue.kind==='flow-gap'||issue.kind==='document-mismatch'?[['connect','Подтверждаю переход']]:issue.kind==='missing-actor'?[['actor','Назначить исполнителя']]:issue.kind==='missing-branch'?[['branch','Добавить отрицательную ветвь']]:issue.kind==='missing-return'?[['return','Указать задачу возврата']]:[];
    if(state.clientLlmConfigAllowed||report.provider==='llm') choices.push(['llm','Уточнить с ИИ']);
    for(const [decision,label] of choices) {
      const btn=document.createElement('button');btn.className='btn btn-ghost';btn.textContent=label;
      btn.onclick=()=>answerQuestion(issue.id,answer.value.trim()||(decision==='connect'?'Подтверждаю переход между указанными действиями':''),decision,btn);
      card.append(btn);
    }
    const hint=document.createElement('p');hint.className='hint';hint.textContent='Можно также исправить описание выше и построить схему заново.';card.append(hint);
    $('reviewQuestions').append(card);
  }
  $('clarificationHistory').replaceChildren();
  for(const item of graph.clarifications||[]) {
    const p=document.createElement('div');p.className='item';p.textContent=item.question+' → '+item.answer;$('clarificationHistory').append(p);
  }
}
async function answerQuestion(issueId,answer,decision,btn) {
  if(state.busy) return;
  if(!answer) {showStatus('Введите ответ на вопрос.','error');return;}
  setBusy(btn,true,'Применяю…');
  try {
    const {graph,xml,report}=await api('/api/clarify',{graph:currentGraph(),issueId,answer,decision});
    await renderXml(xml,`«${graph.name}» · ${report.status==='draft'?'черновик':'после уточнения'}`);
    state.graph=graph;renderReport(report);showStatus('Ответ применён. Остальные неопределённости сохранены.');
  } catch(e) {showStatus('Ответ не применён: '+e.message,'error');}
  finally {setBusy(btn,false);}
}

/* ---------- Генерация и правки ---------- */

async function generate() {
  if (state.busy) return;
  const text = $('processText').value.trim();
  if (text.length < 3) { showStatus('Опишите процесс хотя бы одним предложением.', 'error'); return; }
  if (state.xml && !confirm('Новая генерация заменит текущую диаграмму. Сохраните её через .bpmn, если она нужна. Продолжить?')) return;
  setBusy($('generateBtn'), true, 'Компилирую…');
  showStatus('Парсинг текста → верификация графа → сборка BPMN 2.0…', 'busy');
  try {
    const { graph, xml, report } = await api('/api/generate', { text });
    await renderXml(xml, `«${graph.name}» · ${report.status==='draft'?'черновик · ':''}узлов: ${report.stats.nodes} · источник: ${report.provider === 'llm' ? 'LLM ' + report.model : 'встроенный парсер'}`);
    state.graph = graph;
    const badge = $('providerBadge');
    badge.textContent = report.provider === 'llm' ? 'LLM: ' + report.model : 'эвристический режим';
    badge.className = 'badge ' + (report.provider === 'llm' ? 'badge-llm' : 'badge-off');
    renderReport(report);
    $('editCard').hidden = false;
    state.edits = 0;
    $('editHistory').innerHTML = '';
    showStatus(`${report.status==='draft'?'Черновик построен. Ответьте на вопросы слева.':'Схема построена.'} ${report.ms} мс. ${report.fallbackReason ? 'Режим: ' + report.fallbackReason : ''}`);
  } catch (e) {
    showStatus('Ошибка: ' + e.message, 'error');
  } finally {
    setBusy($('generateBtn'), false);
  }
}

async function applyEdit() {
  if (state.busy) return;
  const instruction = $('editInput').value.trim();
  if (!instruction || !state.graph) return;
  setBusy($('editBtn'), true, '…');
  try {
    const { graph, xml, report } = await api('/api/edit', { graph: currentGraph(), instruction });
    await renderXml(xml, `«${graph.name}» · правка #${state.edits + 1}`);
    state.edits++;
    state.graph = graph;
    renderReport(report);
    const item = document.createElement('div');
    item.className = 'item';
    item.innerHTML = `<b>#${state.edits}</b> ${escapeHtml(instruction)}`;
    $('editHistory').prepend(item);
    $('editInput').value = '';
    showStatus(`Правка применена за ${report.ms} мс. ${report.fallbackReason || ''}`);
  } catch (e) {
    showStatus('Правка не применена: ' + e.message, 'error');
  } finally {
    setBusy($('editBtn'), false);
  }
}

/* ---------- Экспорт ---------- */

function download(name, blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}

function safeName() {
  return (state.graph && state.graph.name ? state.graph.name : 'процесс')
    .replace(/[^\wа-яА-ЯёЁ -]/g, '').trim().slice(0, 60) || 'diagram';
}

async function exportSvg() {
  if (!state.xml || state.busy) return;
  const { svg } = await state.viewer.saveSVG();
  download(safeName() + '.svg', new Blob([svg], { type: 'image/svg+xml' }));
}

async function exportPng() {
  if (!state.xml || state.busy) return;
  const { svg } = await state.viewer.saveSVG();
  const url = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
  const img = new Image();
  await new Promise((resolve, reject) => { img.onload = resolve; img.onerror = reject; img.src = url; });
  const scale = 2;
  const canvas = document.createElement('canvas');
  canvas.width = img.width * scale || 1600;
  canvas.height = img.height * scale || 900;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  URL.revokeObjectURL(url);
  await new Promise(r => canvas.toBlob(b => { download(safeName() + '.png', b); r(); }, 'image/png'));
}

/* ---------- Мелочи UI ---------- */

function setBusy(btn, busy, label) {
  state.busy = busy;
  for (const id of ['generateBtn','editBtn','importBtn','textFileBtn','checkBtn']) $(id).disabled = busy;
  for(const button of document.querySelectorAll('#reviewQuestions button')) button.disabled=busy;
  $('canvas').style.pointerEvents = busy ? 'none' : '';
  if (busy) { btn.dataset.label = btn.textContent; btn.disabled = true; btn.textContent = label || '…'; }
  else { btn.disabled = false; btn.textContent = btn.dataset.label || btn.textContent; }
}

function showStatus(msg, kind = '') {
  const bar = $('statusBar');
  bar.hidden = false;
  bar.className = 'statusbar ' + kind;
  bar.textContent = msg;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function loadHealth() {
  try {
    const res = await fetch('/api/health');
    const h = await res.json();
    state.clientLlmConfigAllowed = h.clientLlmConfigAllowed;
    for (const id of ['cfgBaseUrl','cfgModel','cfgApiKey','settingsSave']) $(id).disabled = !h.clientLlmConfigAllowed;
    const badge = $('providerBadge');
    const local = llmConfig();
    if (local?.baseUrl && local?.model) { badge.className = 'badge badge-llm'; badge.textContent = 'LLM настроена: ' + local.model; }
    else if (h.llmConfigured) { badge.className = 'badge badge-llm'; badge.textContent = 'LLM настроена: ' + h.model; }
    else { badge.className = 'badge badge-off'; badge.textContent = 'офлайн-режим · встроенный парсер'; }
  } catch { /* ignore */ }
}

async function loadExamples() {
  try {
    const names = ['energy.txt', 'zakupka.txt', 'incident.txt', 'onboarding.txt','review/gap.txt','review/branch.txt','review/external.txt'];
    const labels = { 'energy.txt':'Энергооборудование', 'zakupka.txt': 'Закупка', 'incident.txt': 'Инцидент ИБ', 'onboarding.txt': 'Онбординг','review/gap.txt':'Разрыв логики','review/branch.txt':'Не хватает ветви','review/external.txt':'Подрядчик' };
    for (const f of names) {
      const chip = document.createElement('button');
      chip.className = 'chip';
      chip.textContent = labels[f] || f;
      chip.onclick = async () => {
        if (state.busy) return;
        const r = await fetch('/examples/' + f);
        $('processText').value = await r.text();
        $('examplesChooser').open=false;
      };
      $('examplesRow').appendChild(chip);
    }
  } catch { /* ignore */ }
}

function initSettings() {
  const dlg = $('settingsDlg');
  $('settingsBtn').onclick = () => {
    $('cfgBaseUrl').value = localStorage.getItem('cfg.baseUrl') || '';
    $('cfgModel').value = localStorage.getItem('cfg.model') || '';
    $('cfgApiKey').value = sessionStorage.getItem('cfg.apiKey') || '';
    dlg.showModal();
  };
  $('settingsSave').onclick = (e) => {
    e.preventDefault();
    localStorage.setItem('cfg.baseUrl', $('cfgBaseUrl').value.trim());
    localStorage.setItem('cfg.model', $('cfgModel').value.trim());
    sessionStorage.setItem('cfg.apiKey', $('cfgApiKey').value.trim());
    dlg.close();
    loadHealth();
  };
}

/* ---------- bootstrap ---------- */

window.addEventListener('DOMContentLoaded', () => {
  localStorage.removeItem('cfg.apiKey');
  initViewer();
  $('toolsBtn').onclick = () => $('canvas').classList.toggle('show-tools');
  initSettings();
  loadHealth();
  loadExamples();
  $('generateBtn').onclick = generate;
  $('editBtn').onclick = applyEdit;
  $('editInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') applyEdit(); });
  $('checkBtn').onclick=async()=>{
    if(!state.xml||state.busy) return;
    setBusy($('checkBtn'),true,'Проверяю…');
    try {const {graph,xml,report}=await api('/api/compile',{graph:currentGraph()});await renderXml(xml,`«${graph.name}» · ${report.status==='draft'?'черновик':'проверено'}`);state.graph=graph;renderReport(report);showStatus('Структура проверена. Проверьте также смысл действий и ветвлений.');}
    catch(e) {showStatus(e.message,'error');}finally {setBusy($('checkBtn'),false);}
  };
  $('textFileBtn').onclick=()=>$('textFile').click();
  $('textFile').onchange=async()=>{
    const file=$('textFile').files[0];if(!file) return;
    try {if(file.size>256*1024) throw new Error('Файл слишком большой');const text=await file.text();if(text.length>20000) throw new Error('Описание длиннее 20 000 символов');$('processText').value=text;showStatus('Описание загружено. Нажмите «Построить диаграмму».');}
    catch(e) {showStatus(e.message,'error');}finally {$('textFile').value='';}
  };
  $('dlBpmn').onclick = async () => { if (!state.xml || state.busy) return; const { xml } = await state.viewer.saveXML({format:true}); download(safeName() + '.bpmn', new Blob([xml], { type: 'application/xml' })); };
  $('dlSvg').onclick = exportSvg;
  $('dlPng').onclick = exportPng;
  $('importBtn').onclick = () => $('importFile').click();
  $('importFile').onchange = async () => {
    const file = $('importFile').files[0];
    if (!file) return;
    if (state.xml && !confirm('Открытие файла заменит текущую диаграмму. Продолжить?')) { $('importFile').value=''; return; }
    setBusy($('importBtn'), true, 'Открываю…');
    try {
      if (file.size > 2*1024*1024) throw new Error('Максимальный размер BPMN-файла 2 МБ');
      await renderXml(await file.text(), file.name);
      state.graph = {name:file.name.replace(/\.(bpmn|xml)$/i,'')};
      $('reportCard').hidden = true;
      $('editCard').hidden = false;
      renderReview({provider:'import'});
      showStatus('BPMN открыт. Можно редактировать и экспортировать.');
    } catch (err) { showStatus(err.message,'error'); }
    finally { setBusy($('importBtn'), false); $('importFile').value = ''; }
  };
});

// Читаем текущую модель после ручных правок, а не устаревший граф генерации.
function currentGraph() {
  const elements = state.viewer.get('elementRegistry').getAll().filter(e=>!e.labelTarget);
  const supported = ['startEvent','endEvent','task','exclusiveGateway','parallelGateway','inclusiveGateway'];
  const nodes = [], edges = [], lanes = [],participants=[],messages=[];
  const process=elements.find(e=>e.businessObject.$type==='bpmn:Participant'&&e.businessObject.processRef)?.businessObject.processRef||elements.find(e=>e.businessObject.$type==='bpmn:Process')?.businessObject;
  const metadata=readMetadata(process);
  const laneByNode = new Map();
  for (const e of elements) if (e.businessObject.$type === 'bpmn:Lane') {
    for (const ref of e.businessObject.flowNodeRef || []) laneByNode.set(ref.id, e.businessObject.name || 'Участник процесса');
  }
  if (elements.filter(e=>e.businessObject.$type==='bpmn:Participant'&&e.businessObject.processRef).length>1) {
    throw new Error('Текстовые правки поддерживают один процесс. Несколько пулов можно редактировать вручную и экспортировать.');
  }
  for (const e of elements) {
    const bo = e.businessObject;
    if (bo.$type === 'bpmn:Lane') { lanes.push(bo.name || 'Участник процесса'); continue; }
    if (bo.$type === 'bpmn:SequenceFlow') { edges.push({from:bo.sourceRef.id,to:bo.targetRef.id,label:bo.name || ''}); continue; }
    if(bo.$type==='bpmn:Participant'&&!bo.processRef) {participants.push({id:bo.id,name:bo.name||'Внешний участник'});continue;}
    if(bo.$type==='bpmn:MessageFlow') {const trace=readMetadata(bo);messages.push({from:bo.sourceRef.id,to:bo.targetRef.id,label:bo.name||'',...(typeof trace.source==='string'?{source:trace.source}:{})});continue;}
    if(['bpmn:TextAnnotation','bpmn:Association'].includes(bo.$type)) {
      if(/^(Issue_|Issue_Association_)/.test(bo.id)) continue;
      throw new Error('Произвольные аннотации можно править вручную; текстовая правка не должна их терять.');
    }
    const type = bo.$type.replace('bpmn:','');
    const irType = type.charAt(0).toLowerCase()+type.slice(1);
    if (supported.includes(irType)) {
      let parent = e.parent;
      while (parent && parent.type!=='bpmn:Lane') parent=parent.parent;
      const trace=readMetadata(bo);
      nodes.push({id:bo.id,type:irType,label:bo.name || '',lane:laneByNode.get(bo.id) || parent?.businessObject.name || 'Участник процесса',
        ...(typeof trace.source==='string'?{source:trace.source}:{}),...(Array.isArray(trace.inputs)?{inputs:trace.inputs}:{}),...(Array.isArray(trace.outputs)?{outputs:trace.outputs}:{})});
    } else if (!['bpmn:Process','bpmn:Participant','bpmn:Collaboration'].includes(bo.$type)) {
      throw new Error('Для текстовой правки поддерживаются обычные задачи, старт/конец и XOR/AND. Этот элемент можно править вручную и экспортировать.');
    }
  }
  return {name:state.graph?.name || process?.name || 'Процесс',nodes,edges,lanes,participants,messages,
    draft:Boolean(metadata.draft),issues:Array.isArray(metadata.issues)?metadata.issues:[],clarifications:Array.isArray(metadata.clarifications)?metadata.clarifications:[],sourceText:typeof metadata.sourceText==='string'?metadata.sourceText:''};
}
